/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

int main()
{
    float gallons;
    float miles;
    float mpg;
    gallons=16;
    miles=312;
    
    mpg = miles / gallons;
    
    std::cout << "The mpg the car has = "<<mpg<<"\n";

    return 0;
}